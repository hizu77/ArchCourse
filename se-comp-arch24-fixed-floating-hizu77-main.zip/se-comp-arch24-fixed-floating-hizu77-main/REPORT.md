| Лабораторная работа №1 | M3103                           | АОВС |
| ---------------------- | ------------------------------- | ---- |
| Представление чисел    | Гаврилов Михаил Тимофеевич      | 2024 |


## Инструментарий
> Работа выполняется на C++ (C++20).
 

## Вариант
> Была выполнена упрощенная версия работы, c округление только к нулю(lite).

## Результат работы на тестовых данных: [Last successful action](<https://github.com/skkv-itmo-comp-arch/se-comp-arch24-fixed-floating-hizu77/actions/runs/8131622388>)

# Описание:
# 1.Структура проекта
Проект состоит из 5 файлов : main.cpp; FixedPoint.cpp, .h; FloatingPoint.ccp, h.
В зависимости от входных данных программа умеет запускать арифметику FloatingPoint или FixedPoint, а также выдавать различные ошибки при некорректных параметров. Программа запускается через main.cpp.


# 2.Стркутура FixedPoint
```c++
InputFixedData ParseFixedPoint(int argc, char** argv)
```

Реализован парсер для входных парметров FixedPoint, который возвращает нам "распаршенные" входные параметры.

В него входят такие функции:
-
- Парсит входное число, проверят его на "правильность", и с помощью std::stoll преобразует исходное строковое представление числа из 16 системы счисления в 10СС, также с помощью маски ```1ull << (fractional_bits + main_bits)) - 1``` обнуляем все биты, кроме заданных.
```c++
uint32_t ParseOneFixed(std::string& value, uint32_t main_bits, uint32_t fractional_bits) {
```
- Парсит количество целых и дробных битов, возвращает ```std::pair<a,b>```, где а - целые биты, b - дробные биты. Просто проходимся по строчке, если мы еще не встретии точку то изменям целые биты, иначе дробные.
```c++
    std::pair<uint8_t ,uint8_t> ParseBits(std::string& all_bits) {
}
```
- Парсит командую строку фикс точки. Если оличество аргументов либо == 5, либо > 6(включая самый первый аргумент - путь к файлу), то выходит из программы с кодом ```EXIT_FAILURE```(в случае любой ошибки ввода ```EXIT_FAILURE```). Далее парсит 1 аргумент - биты(через ```ParseBits```). Затем парсит код округления(реализован только 0, иначе ошибка). Затем парсит одно входное число(через ```ParseOneFixed```). Если количество аргументов > 4, то это значит что нам задана арифметическая операция, и мы должны аналогично распарсить код операции и второе число.
```c++
InputFixedData ParseFixedPoint(int argc, char** argv) {
```
Struct FixedOneValue(число с фикс точкой)
-

```c++
struct FixedOneValue{
FixedOneValue() = default;
    FixedOneValue(uint64_t cur_val, uint8_t main, uint8_t fractional);

    uint8_t GetSign() const;
    uint32_t InAdditional(uint32_t cur_val) const;


    uint32_t value{};
    uint8_t main_bits{};
    uint8_t fractional_bits{};

    uint32_t main_part = 0;
    uint32_t fractional_part = 0;
    
    FixedOneValue operator+(const FixedOneValue& other) const;

    FixedOneValue operator-(const FixedOneValue& other) const;

    FixedOneValue operator*(const FixedOneValue& other) const;

    FixedOneValue operator/(const FixedOneValue& other) const;
}
std::ostream& operator<<(std::ostream &ostream, FixedOneValue& value);
```

Реализован класс FixedPoint с перегруженными операторами "+, -,*,/" и "<<". Он является фактически "fixed_point value", в него входит сама запись битов данного числа, количество целых и дробных битов, а также вспомогательные методы ```uint8_t GetSign() const;
    uint32_t InAdditional(uint32_t cur_val) const;```.

- GetSign - метод, позволяющий получить знак числа, т.к число в доп коде, то 1 - минус, 0 - плюс. Данный метод возвращает самый старший бит из исходного количества битов(с помощью побитового сдвига на ```fractional_bits + main_bits - 1```.
```c++
uint8_t FixedOneValue::GetSign() const {
    return (value >> (fractional_bits + main_bits - 1)) & 1;
}
```

- InAdditioanl - метод позволяющий перевести отрицательное число из доп кода с помощью инвертирования всех разрядов на противоположные и прибавлением 1. Так как нам нужно только исходное количество битов и мы можем за него "вывалиться", то остальные биты, кроме исходных обнуляем c помощью маски ```1ull << (fractional_bits + main_bits)) - 1```, в ней используем 64 битное число, чтобы "обойти" переполнение.
```c++
uint32_t FixedOneValue::InAdditional(uint32_t cur_val) const {
    return (~cur_val + 1) & ((1ull << (fractional_bits + main_bits)) - 1);
}
```

1.Operator+(сложение)
```c++
FixedOneValue FixedOneValue::operator+(const FixedOneValue& other) const {
    uint32_t new_value = (value + other.value) & ((1ull << (fractional_bits + main_bits)) - 1);
    return {new_value, main_bits, fractional_bits};
}
```
Так как нам нужно всегда сохранять инвариант main_bits.fractional_bits, то просто сложим два числа и обнулим все остальные биты. Так как арифметические операции двоичных чисел равносильны десятичным, то все будет работать корректно(а также учитываем, что все в доп коде и мы можем не задумываться о знаках).
 
2. Operator-
```c++
FixedOneValue FixedOneValue::operator-(const FixedOneValue& other) const {
    uint32_t new_value = (value - other.value) & ((1ull << (fractional_bits + main_bits)) - 1);
    return {new_value, main_bits, fractional_bits};
}
```
Аналогично сложению, но в этот раз надо сделать вычитания двух чисел.

3. Operator*
```c++
FixedOneValue FixedOneValue::operator*(const FixedOneValue& other) const {
    uint8_t cur_sign = GetSign();
    uint8_t other_sign = other.GetSign();
    uint8_t new_sign = cur_sign ^ other_sign;


    uint32_t cur_value = (cur_sign ? InAdditional(value) : value);
    uint32_t other_value = (other_sign ? InAdditional(other.value) : other.value);

    uint32_t new_value = ((static_cast<uint64_t>(cur_value) * other_value) >> fractional_bits)  & ((1ull << (fractional_bits + main_bits)) - 1);

    uint32_t result_value = (new_sign ? InAdditional(new_value) : new_value);

    return {result_value, main_bits, fractional_bits};
}
```
Для начала определям знак конечной переменной. Умножение удобно делать в обычном коде(так как при умножении бит знака может не измениться, пример : умножение отрицательных, т.е 1 * 1 = 1, а должно быть 0), поэтому переводим, если число отрицательное. При умножении у нас добавляются новые биты и происходит переполнение, поэтому кастим к 64 битному числу и сдигаем вправо на количество дробных битов, чтобы оставить только нужные(записываем все в 32 битное число, по условию формат данных чисел не превосходт 32 бит).Далее обнуляем все биты кроме исходных main_bits + fractional_bits с помощью нашей маски и переводим в доп код, если число отрицательное.

4. Operator/
```c++
FixedOneValue FixedOneValue::operator/(const FixedOneValue& other) const {
    if (other.value == 0) {
        std::cerr << "division by zero";
        exit(0);
    }

    uint8_t cur_sign = GetSign();
    uint8_t other_sign = other.GetSign();
    uint8_t new_sign = cur_sign ^ other_sign;

    uint32_t cur_value = (cur_sign ? InAdditional(value) : value);
    uint32_t other_value = (other_sign ? InAdditional(other.value) : other.value);

    uint32_t new_value = ((static_cast<uint64_t>(cur_value) << fractional_bits) / other_value) & ((1ull << (fractional_bits + main_bits)) - 1);

    uint32_t result_value = (new_sign ? InAdditional(new_value) : new_value);

    return {result_value, main_bits, fractional_bits};
}
```
Для начала проверям не является ли делитель 0.
Далее аналогично умножению получаем результирующий знак и два числа в обычной форме(преобразуем отрицательные в положительные и запоминаем знак). Кастим делимое к 64 битному числу и уже сдвигаем влево на количество дробных битов(сдвиг влево на количество дробных битов аналогичен умножению числа на степень двойки, что эквивалентно увеличению значения числа). Делим на делитель и обнуляем биты за границей нашего диапазона и переводим, если необходимо в доп код.


5. Operator<<
```c++
std::ostream& operator<<(std::ostream &ostream, FixedOneValue& value) {
    uint8_t sign = value.GetSign();
    uint32_t edited_value = (sign ? value.InAdditional(value.value) : value.value);

    if (sign) {
        ostream << "-";
    }

    value.main_part = (edited_value >> value.fractional_bits);
    value.fractional_part = ((edited_value & ((1ull << value.fractional_bits) - 1)));
    value.fractional_part = (value.fractional_part * kRoundingFactor) >> value.fractional_bits;

    ostream << value.main_part << ".";

    std::string fractional = std::to_string(value.fractional_part);
    if (fractional.size() == 1) fractional = "00" + fractional;
    if (fractional.size() == 2) fractional = "0" + fractional;

    ostream << fractional;
    return ostream;
}
```
Округление к нулю равносильно отрасыванию битов.

Получеам знак и необходимое число в нужной форме(преобразуем отрицательные в положительные и запоминаем знак). Получаем биты целой части отбрасыванием дробных битов, получаем дробные биты обнулением всех остальных битов(с помощью нашей маски, которую мы много раз использовали). Так как мы округляем до 3 цифр в десятичном представлении, то умножаем дробную часть на 1000 и отбрасываем(опять же окргуление к нулю равносильно отбрасыванию) исходное количество дробных битов(так как мы умножили предварительно дробную часть на 1000, то в результате останется округленное до 3 знаков десятичное представление дробной части).Получем десятичное представление дробной части. Так как нам нужно 3 цифры в дробной части, то, если их не хватает дописываем вперед нолики(пример получили 26, но корректно выводить 026).

# 3.Структура Floating Point
```c++
InputFloatingData ParseFloatingPoint(int argc, char** argv)
```

Реализован парсер входных данных, который возвращает нам "распаршенный" struct Floating point(парсер аналогичный парсеру в FixedPoint).

FloatingOneValue
-
```c++
struct FloatingOneValue {
    
    FloatingOneValue() = default;
    FloatingOneValue(uint64_t cur_value, char cur_precision);
    FloatingOneValue(char cur_precision, uint8_t cur_sign, uint64_t cur_mantissa, int32_t cur_exponent);

    uint64_t GetFullMantissa() const;
    void CorrectValue();

    uint64_t value{};
    char precision;

    uint32_t exponent_size;
    uint32_t mantissa_size;

    uint8_t sign;
    int32_t exponent;
    uint64_t mantissa; // control overflowing

    std::string special_meanings = kDefault;
    bool subnormal = false;
    
    FloatingOneValue operator+(const FloatingOneValue& other) const;

    FloatingOneValue operator-(const FloatingOneValue& other) const;

    FloatingOneValue operator*(const FloatingOneValue& other) const;

    FloatingOneValue operator/(const FloatingOneValue& other) const;

};

std::ostream& operator<<(std::ostream &ostream, FloatingOneValue& value);
```
Аналогично Fixed point реализована структура Floating point с перегруженными операторами "+,-,*,/" и "<<", структура хранит в себе precision(half, single), само число, записанное в данном precision(value), размер экспоненты и мантиссы(в зависимости от типа), а также и саму экспоненту и мантиссу, имеется флаг контроля денормализованного состояния и специальных значений, таких как inf, nan... И методы :  ```uint64_t GetFullMantissa() const;
void CorrectValue();```. GetFullMantissa() - метод выдающий мантиссу с неявным битым(0 или 1, в зависимости от состояния числа), а также CorrectValue - данная функция выполняет коррекцию значений для чисел с плавающей запятой, например, обрезает или увеличивает значения мантиссы и экспоненты, а также определяет специальные состояния числа, такие как ноль и денормализованное число.

1. Constructor
-  ``` c++
    FloatingOneValue::FloatingOneValue(uint64_t cur_value, char cur_precision)
    : precision(cur_precision)
    , value(cur_value)
    {
        if (cur_precision == 'h') {
            mantissa_size = 10;
            exponent_size = 5;
        } else {
            mantissa_size = 23;
            exponent_size = 8;
        }

        sign = (cur_value >> (mantissa_size + exponent_size)); // get sign
        exponent = static_cast<int32_t>((cur_value >> mantissa_size) & ((1 << exponent_size) - 1)); // get exponent
        mantissa = (cur_value & ((1 << mantissa_size) - 1)); // get mantissa
    
        if (exponent == 0 && mantissa == 0) {
            special_meanings = "0";
        } else if (exponent == 0 && mantissa != 0) {
            subnormal = true;
            exponent = 1;
        } else if ((exponent == ((1 << exponent_size) - 1)) && mantissa == 0) {
            special_meanings = "inf";
        } else if ((exponent == ((1 << exponent_size) - 1)) && mantissa != 0) {
            special_meanings = "nan";
        }
    }
    ```
    Конструктор, который конфигурирует структура из входных данных. Рассматриваются частные случаи, такие как inf, not a number, zero, а также субнормальность числа(с минимальной экспонентой со сдвигом). Знак числа получаем сдвигом на общее количество битов экспоненты и мантиссы. Экспоненту получаем сдвигом вправо на количество битов мантиссы и обнулением всех других битов маской из 111.111 размера экспоненты.Мантиссу получаем обнулением всех остальных битов маской из 11..1 размера мантиссы.
    
    Если экспонента = 0 и мантисса = 0, то это 0.
    
    Если экспонента состоит из всех 1 и мантисса не равна 0, то это not a number.
    
    Если экспонента состоит из всех 1 и мантисса равна 0, то это inf.
    
    Если экспонента равна 0 и мантисса не равна 0, то это денормализованное число, т.е в этом числе нет неявной 1 перед мантиссой и порядок минимально возможный. Присваиваем порядку 1(экспонента со сдвигом)
 - ``` c++
     FloatingOneValue::FloatingOneValue(char cur_precision, uint8_t cur_sign, uint64_t cur_mantissa, int32_t cur_exponent)
      : precision(cur_precision)
      , sign(cur_sign)
      , mantissa(cur_mantissa)
      , exponent(cur_exponent)
    
    {
        ...
    }
    ```
    Аналогично имеется конструктор, позволяющий строить число по следующим параметрам: тип числа, знак, мантисса, экспонента(удобен для контруировния nan,inf и т.д, а также для чисел, являющихся результатом арифметической операции). 

2. Operator+
```c++
FloatingOneValue FloatingOneValue::operator+(const FloatingOneValue &other) const {
    if (special_meanings == "nan" || other.special_meanings == "nan") {
        return FloatingOneValue(precision, 0, 1, (1 << exponent_size) - 1);
    }
    if (special_meanings == "inf" && other.special_meanings == "inf") {
        if ((sign ^ other.sign) == 1) {
            return FloatingOneValue(precision, 0, 1, (1 << exponent_size) - 1);
        }
        return FloatingOneValue(precision, sign, 0, (1 << exponent_size) - 1);
    }
    if (special_meanings == "inf") {
        return FloatingOneValue(precision, sign, 0, (1 << exponent_size) - 1);

    }
    if (other.special_meanings == "inf") {
        return FloatingOneValue(precision, other.sign, 0, (1 << exponent_size) - 1);
    }
    if ((sign ^ other.sign) == 1) {
        if (sign) {
            return (other - *this);
        }
        return (*this - other);
    }

    uint64_t first_mantissa = GetFullMantissa();
    uint64_t second_mantissa = other.GetFullMantissa();

    int32_t max_exp = std::max(exponent, other.exponent);

    first_mantissa >>= (max_exp - exponent);
    second_mantissa >>= (max_exp - other.exponent);
    
    uint64_t result_mantissa = first_mantissa + second_mantissa;

    auto result = FloatingOneValue(precision, sign, result_mantissa, max_exp);
    result.CorrectValue();
    return result;


}
```
Сначала проверяются особые случаи сложения.

Если одно число nan, то результат тоже nan.

Если два числа inf, то : если они разных знаков, то nan; иначе inf с данным знаком.

Если только одно из чисел inf, то результат тоже inf с этим же знаком.

Далее идет проверка на то что мы складываем два обычных числа, но разных знаков.В этом случае мы можем заменить операцию сложения на вычитание.Если они одних знаков, то мы получаем их полные мантиссы, приводим порядки к одному значению(если они будут разных порядков мы не имеем право их просто складывать) и изменяем мантиссы(с помощью побитового сдвига на разницу экспонент). Конструируем число с тем же знаком и типом, а также новым порядком(который у них одинаковый) и суммой данных мантисс(так как мы привели порядки к одному значению). Затем корректируем его(Correct).

3. Operator*
```c++
FloatingOneValue FloatingOneValue::operator*(const FloatingOneValue &other) const {
    if (special_meanings == "nan" || other.special_meanings == "nan") {
        return FloatingOneValue(precision, 0, 1, (1 << exponent_size) - 1);
    }
    if ((special_meanings == "0" && other.special_meanings == "inf") || (special_meanings == "inf" && other.special_meanings == "0")) {
        return FloatingOneValue(precision, 0, 1, (1 << exponent_size) - 1);

    }
    if ((special_meanings == "0" && other.special_meanings != "inf") || special_meanings != "inf" && other.special_meanings == "0") {
        return FloatingOneValue(precision, 0, 0, 0);

    }

    if ((special_meanings != "0" && other.special_meanings == "inf") || special_meanings == "inf" && other.special_meanings != "0") {
        return FloatingOneValue(precision, sign ^ other.sign, 0, (1 << exponent_size) - 1);

    }

    int32_t sum_exp = exponent + other.exponent;
    sum_exp -= (precision == 'h' ? 15 : 127);

    uint64_t new_mantissa = (GetFullMantissa() * other.GetFullMantissa()) >> mantissa_size;
    uint8_t new_sign = sign ^ other.sign;

    FloatingOneValue result = FloatingOneValue(precision, new_sign, new_mantissa, sum_exp);
    result.CorrectValue();

    return result;

}
```
Сначала проверяем особые случаи.

Если одно из чисел nan, то результат тоже nan.

Если 0 * inf, то результат тоже nan.

Если 0 * !inf, то результат 0.

Так как мы умножаем числа, то экспоненты скалыдваются(так как у них одинаковое основание), а мантиссы перемножаются.

То есть мы складываем экспоненты и результат уменьшаем на сдвиг данного типа(при умножении они складываются и мы сдвинули число 2 раза(так как изначально экспонента хранится со сдвигом), поэтому уменьшаем). Перемножаем мантиссы и отбрасываем лишние биты мантиссы(как в умножении в FixedPoint).Конструируем число с xor`ом данных знаков(так как, если они разные, то результат будет отрицательный, иначе положительный), а также новым порядком(сложенными исходными) и новой мантиссой(перемноженными исходными). Затем корректируем его.

4. Operator/
```c++
FloatingOneValue FloatingOneValue::operator/(const FloatingOneValue &other) const {
    if (special_meanings == "nan" || other.special_meanings == "nan") {
        return FloatingOneValue(precision, 0, 1, (1 << exponent_size) - 1);
    }
    if (special_meanings == "0" && other.special_meanings == "0") {
        return FloatingOneValue(precision, 0, 1, (1 << exponent_size) - 1);
    }
    if (special_meanings == "inf" && other.special_meanings == "inf") {
        return FloatingOneValue(precision, sign ^ other.sign, 1, (1 << exponent_size) - 1);
    }
    if (special_meanings == "inf") {
        return FloatingOneValue(precision, sign ^ other.sign, 0, (1 << exponent_size) - 1);
    }
    if (other.special_meanings == "0") {
        return FloatingOneValue(precision, sign ^ other.sign, 0, (1 << exponent_size) - 1);
    }
    if (special_meanings == "0") {
        return FloatingOneValue(precision, 0, 0, 0);

    }


    int32_t dif_exp = exponent - other.exponent;
    dif_exp += (precision == 'h' ? 15 : 127);

    uint64_t new_mantissa = (GetFullMantissa() << mantissa_size) / other.GetFullMantissa();
    uint8_t new_sign = sign ^ other.sign;

    FloatingOneValue result = FloatingOneValue(precision, new_sign, new_mantissa, dif_exp);
    result.CorrectValue();

    return result;
}
```
Сначала проверяем особые случаи.

Если одно из чисел nan, то результат тоже nan.

Если 0 / 0 или inf / inf, то результат тоже nan.

Если inf / !inf, то результат inf.

Если x / 0, то результат inf.

Если 0 / x, то результат 0.

Так как мы делим числа, то экспоненты вычитаются(так как у них одинаковое основание), а мантиссы делятся.

То есть мы вычитаем экспоненты и результат увеличиваем на сдвиг данного типа(при делении они вычитаются и мы сдвинули число 2 раза(так как изначально экспонента хранится со сдвигом), поэтому прибавляем). Затем получаем полные мантиссы, расширяем вправо первую мантиссу на количество битов мантиссы и делим ее на вторую(как в FixedPoint).
Конструируем число с xor`ом данных знаков(так как, если они разные, то результат будет отрицательный, иначе положительный), а также новым порядком(вычтенными исходными) и новой мантиссой(деленными исходными). Затем корректируем его.

5. Operator-

```c++
FloatingOneValue FloatingOneValue::operator-(const FloatingOneValue &other) const {
    if (special_meanings == "nan" || other.special_meanings == "nan") {
        return FloatingOneValue(precision, 0, 1, (1 << exponent_size) - 1);
    }
    if (special_meanings == "inf" && other.special_meanings == "inf") {
        if ((sign ^ other.sign) == 1) {
            return FloatingOneValue(precision, 0, 1, (1 << exponent_size) - 1);
        }
        return FloatingOneValue(precision, sign, 0, (1 << exponent_size) - 1);
    }
    if (special_meanings == "inf") {
        return FloatingOneValue(precision, sign, 0, (1 << exponent_size) - 1);

    }
    if (other.special_meanings == "inf") {
        return FloatingOneValue(precision, other.sign, 0, (1 << exponent_size) - 1);
    }

    if ((sign ^ other.sign) == 1) {
        if (other.sign) {
            return *this + FloatingOneValue(precision, 0, other.mantissa, other.exponent);
        }
        return *this + FloatingOneValue(precision, 1, other.mantissa, other.exponent);
    }

    uint64_t first_mantissa = GetFullMantissa();
    uint64_t second_mantissa = other.GetFullMantissa();

    int32_t max_exp = std::max(exponent, other.exponent);

    first_mantissa >>= (max_exp - exponent);
    second_mantissa >>= (max_exp - other.exponent);
    uint64_t new_mantissa = std::max(first_mantissa, second_mantissa) - std::min(first_mantissa, second_mantissa);

    uint8_t new_sign = (first_mantissa > second_mantissa ? sign : other.sign ^ 1);
    FloatingOneValue result = FloatingOneValue(precision, new_sign, new_mantissa, max_exp);
    result.CorrectValue();
    return result;

}
```
Сначала проверяем особые случаи.

Если одно число nan, то результат тоже nan.

Если два числа inf, то : если они разных знаков, то nan; иначе inf с данным знаком.

Если только одно из чисел inf, то результат тоже inf с этим же знаком.

Далее идет проверка на то что мы вычитаем два обычных числа, но разных знаков.В этом случае мы можем заменить операцию вычитания на сложение(но надо учитывать знаки результата).Если они одних знаков, то мы получаем их полные мантиссы, приводим порядки к одному значению, изменяем мантиссы и берем абсолютную разность этих значений(что то похожее на сложение, но используем операцию вычитания). Если 1 число больше второго, то берем его знак, иначе инвертируем знак второго числа(так как у нас перед ним знак минус - вычитание).Конструируем по этим данным результат и затем корректируем его.

6. Operator<<
```c++
std::ostream& operator<<(std::ostream &ostream, FloatingOneValue& value) {
    if (value.special_meanings == "nan") {
        ostream << "nan";
        return ostream;
    }

    if (value.special_meanings == "inf") {
        ostream << (value.sign > 0 ? "-inf" : "inf");
        return ostream;
    }

    ostream << (value.sign > 0 ? "-0x" : "0x");
    ostream << (value.special_meanings == "0" ? "0." : "1.");

    uint32_t cur_mantissa = value.mantissa;
    int32_t cur_exponent = value.exponent;

    if (value.subnormal) {
        while (((cur_mantissa >> value.mantissa_size) & 1) == 0 && cur_mantissa != 0) {
            //until the value becomes zero or the most significant bit of the significant part becomes 1
            cur_mantissa = (cur_mantissa << 1);
            --cur_exponent;
        }
    }

    cur_mantissa &= ((1 << value.mantissa_size) - 1); // the value of the significant part remains within the acceptable size.
    cur_mantissa <<= (value.precision == 'h' ? 2 : 1);

    int32_t bits_count = (value.precision == 'h' ? 12 : 24);

    for (int32_t i = bits_count - 4; i >= 0; i -= 4) {
        ostream << std::hex << ((cur_mantissa >> i) & 0xF);
    }

    ostream << "p";

    if (value.exponent == 0) {
        ostream << "+0";
        return ostream;
    }

    int real_exponent = (value.precision == 'h' ? cur_exponent - 15 : cur_exponent - 127);

    if (real_exponent >= 0) {
        ostream << "+" << std::dec << real_exponent;
    } else {
        ostream << std::dec << real_exponent;
    }

    return ostream;

}
```
Сначала проверяем не является ли число nan или inf. Затем извлекаем знак и неявную цифру.
Проверяем число на денормализованность, если надо корректируем его(сдвигаем побитово влево мантиссу на 1 и уменьшаем экспоненту, пока в значащем разряде ноль). Затем обновляем мантиссу(обнуляя остальные биты с помощью маски из едениц, кроме битов мантиссы). Так как нам надо вывести либо 3, либо 6 разрядов, разделим число на группы по 4 бита и преобразуем в 16-ную систему(будем сдвигать вправо и с помощью маски 0xF, состоящей из 4 едениц получать искомые биты).Далее получаем экспоненту и возвращаем ее к нормальному состоянию (вычитая сдвиг данного типа : 15 или 127. Не забываем, что она может быть нулевая).Переводим в десятичную форму, не забывая о знаке экспоненты и получаем ответ.

